import { Client, ClientCreateInput, ClientUpdateInput, FileUpload } from '../types';
export declare class MyClientModel {
    uploadToS3(file: FileUpload): Promise<string>;
    create(clientData: ClientCreateInput, logoFile?: FileUpload): Promise<Client>;
    findBySlug(slug: string): Promise<Client | null>;
    findAll(): Promise<Client[]>;
    update(slug: string, clientData: ClientUpdateInput, logoFile?: FileUpload): Promise<Client>;
    delete(slug: string): Promise<{
        message: string;
    }>;
    findById(id: number): Promise<Client | null>;
}
export declare const myClientModel: MyClientModel;
//# sourceMappingURL=myClient.d.ts.map