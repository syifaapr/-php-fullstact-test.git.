"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myClientModel = exports.MyClientModel = void 0;
const database_1 = require("../config/database");
const redis_1 = require("../config/redis");
const aws_1 = require("../config/aws");
const helpers_1 = require("../utils/helpers");
const uuid_1 = require("uuid");
class MyClientModel {
    async uploadToS3(file) {
        const fileExtension = file.originalname.split('.').pop();
        const fileName = `client-logos/${(0, uuid_1.v4)()}.${fileExtension}`;
        const params = {
            Bucket: aws_1.S3_CONFIG.bucket,
            Key: fileName,
            Body: file.buffer,
            ContentType: file.mimetype,
            ACL: 'public-read',
        };
        const result = await aws_1.s3.upload(params).promise();
        return result.Location;
    }
    async create(clientData, logoFile) {
        const client = await database_1.pool.connect();
        try {
            await client.query('BEGIN');
            // Sanitize and validate data
            const sanitizedData = helpers_1.Helpers.sanitizeClientData(clientData);
            if (!helpers_1.Helpers.validateClientPrefix(sanitizedData.client_prefix)) {
                throw new Error('Client prefix must be 1-4 uppercase alphanumeric characters');
            }
            // Upload logo if provided
            if (logoFile) {
                sanitizedData.client_logo = await this.uploadToS3(logoFile);
            }
            // Set timestamps
            const now = new Date();
            const query = `
        INSERT INTO my_client (
          name, slug, is_project, self_capture, client_prefix, 
          client_logo, address, phone_number, city, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        RETURNING *
      `;
            const values = [
                sanitizedData.name,
                sanitizedData.slug,
                sanitizedData.is_project,
                sanitizedData.self_capture,
                sanitizedData.client_prefix,
                sanitizedData.client_logo,
                sanitizedData.address || null,
                sanitizedData.phone_number || null,
                sanitizedData.city || null,
                now,
                now,
            ];
            const result = await client.query(query, values);
            const newClient = result.rows[0];
            // Save to Redis
            await (0, redis_1.connectRedis)();
            await redis_1.redisClient.set(newClient.slug, JSON.stringify(newClient));
            await client.query('COMMIT');
            return newClient;
        }
        catch (error) {
            await client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    }
    async findBySlug(slug) {
        // Try Redis first
        await (0, redis_1.connectRedis)();
        const cachedData = await redis_1.redisClient.get(slug);
        if (cachedData) {
            return JSON.parse(cachedData);
        }
        // Fallback to database
        const query = 'SELECT * FROM my_client WHERE slug = $1 AND deleted_at IS NULL';
        const result = await database_1.pool.query(query, [slug]);
        if (result.rows.length === 0) {
            return null;
        }
        const clientData = result.rows[0];
        // Cache in Redis
        await redis_1.redisClient.set(slug, JSON.stringify(clientData));
        return clientData;
    }
    async findAll() {
        const query = 'SELECT * FROM my_client WHERE deleted_at IS NULL ORDER BY created_at DESC';
        const result = await database_1.pool.query(query);
        return result.rows;
    }
    async update(slug, clientData, logoFile) {
        const dbClient = await database_1.pool.connect();
        try {
            await dbClient.query('BEGIN');
            // Upload new logo if provided
            if (logoFile) {
                clientData.client_logo = await this.uploadToS3(logoFile);
            }
            // Set updated_at
            clientData.updated_at = new Date();
            // Build dynamic update query
            const setClauses = [];
            const values = [];
            let paramCount = 1;
            Object.keys(clientData).forEach(key => {
                if (key !== 'slug' && clientData[key] !== undefined) {
                    setClauses.push(`${key} = $${paramCount}`);
                    values.push(clientData[key]);
                    paramCount++;
                }
            });
            if (setClauses.length === 0) {
                throw new Error('No fields to update');
            }
            values.push(slug);
            const whereClause = `slug = $${paramCount}`;
            const query = `
        UPDATE my_client 
        SET ${setClauses.join(', ')} 
        WHERE ${whereClause} AND deleted_at IS NULL
        RETURNING *
      `;
            const result = await dbClient.query(query, values);
            if (result.rows.length === 0) {
                throw new Error('Client not found');
            }
            const updatedClient = result.rows[0];
            // Update Redis
            await (0, redis_1.connectRedis)();
            await redis_1.redisClient.del(slug); // Delete old
            await redis_1.redisClient.set(updatedClient.slug, JSON.stringify(updatedClient)); // Set new
            await dbClient.query('COMMIT');
            return updatedClient;
        }
        catch (error) {
            await dbClient.query('ROLLBACK');
            throw error;
        }
        finally {
            dbClient.release();
        }
    }
    async delete(slug) {
        const dbClient = await database_1.pool.connect();
        try {
            await dbClient.query('BEGIN');
            const query = `
        UPDATE my_client 
        SET deleted_at = $1 
        WHERE slug = $2 AND deleted_at IS NULL
        RETURNING *
      `;
            const result = await dbClient.query(query, [new Date(), slug]);
            if (result.rows.length === 0) {
                throw new Error('Client not found');
            }
            // Remove from Redis
            await (0, redis_1.connectRedis)();
            await redis_1.redisClient.del(slug);
            await dbClient.query('COMMIT');
            return { message: 'Client deleted successfully' };
        }
        catch (error) {
            await dbClient.query('ROLLBACK');
            throw error;
        }
        finally {
            dbClient.release();
        }
    }
    async findById(id) {
        const query = 'SELECT * FROM my_client WHERE id = $1 AND deleted_at IS NULL';
        const result = await database_1.pool.query(query, [id]);
        if (result.rows.length === 0) {
            return null;
        }
        const clientData = result.rows[0];
        // Cache in Redis
        await (0, redis_1.connectRedis)();
        await redis_1.redisClient.set(clientData.slug, JSON.stringify(clientData));
        return clientData;
    }
}
exports.MyClientModel = MyClientModel;
exports.myClientModel = new MyClientModel();
//# sourceMappingURL=myClient.js.map