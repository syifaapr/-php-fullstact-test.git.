export {};
//# sourceMappingURL=app.d.ts.map