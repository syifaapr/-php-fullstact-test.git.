import { Pool } from 'pg';
export declare const pool: Pool;
export declare const testConnection: () => Promise<void>;
//# sourceMappingURL=database.d.ts.map