import AWS from 'aws-sdk';
export declare const s3: AWS.S3;
export declare const S3_CONFIG: {
    bucket: string;
    region: string;
};
//# sourceMappingURL=aws.d.ts.map