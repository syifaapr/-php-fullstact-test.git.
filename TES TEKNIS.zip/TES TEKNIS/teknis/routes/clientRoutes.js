"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const clientController_1 = require("../controllers/clientController");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.post('/clients', upload_1.upload.single('client_logo'), clientController_1.clientController.create.bind(clientController_1.clientController));
router.get('/clients', clientController_1.clientController.getAll.bind(clientController_1.clientController));
router.get('/clients/:slug', clientController_1.clientController.getBySlug.bind(clientController_1.clientController));
router.put('/clients/:slug', upload_1.upload.single('client_logo'), clientController_1.clientController.update.bind(clientController_1.clientController));
router.delete('/clients/:slug', clientController_1.clientController.delete.bind(clientController_1.clientController));
router.use(upload_1.handleUploadError);
exports.default = router;
//# sourceMappingURL=clientRoutes.js.map