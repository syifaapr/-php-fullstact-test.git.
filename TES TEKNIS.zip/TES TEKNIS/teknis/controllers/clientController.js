"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientController = exports.ClientController = void 0;
const myClient_1 = require("../models/myClient");
class ClientController {
    async create(req, res) {
        try {
            const clientData = req.body;
            const logoFile = req.file;
            const newClient = await myClient_1.myClientModel.create(clientData, logoFile);
            const response = {
                success: true,
                data: newClient,
                message: 'Client created successfully'
            };
            res.status(201).json(response);
        }
        catch (error) {
            const response = {
                success: false,
                message: error.message
            };
            res.status(500).json(response);
        }
    }
    async getBySlug(req, res) {
        try {
            const slug = req.params.slug;
            const client = await myClient_1.myClientModel.findBySlug(slug);
            if (!client) {
                const response = {
                    success: false,
                    message: 'Client not found'
                };
                res.status(404).json(response);
                return;
            }
            const response = {
                success: true,
                data: client
            };
            res.json(response);
        }
        catch (error) {
            const response = {
                success: false,
                message: error.message
            };
            res.status(500).json(response);
        }
    }
    async getAll(req, res) {
        try {
            const clients = await myClient_1.myClientModel.findAll();
            const response = {
                success: true,
                data: clients,
                count: clients.length
            };
            res.json(response);
        }
        catch (error) {
            const response = {
                success: false,
                message: error.message
            };
            res.status(500).json(response);
        }
    }
    async update(req, res) {
        try {
            const { slug } = req.params;
            const clientData = req.body;
            const logoFile = req.file;
            const updatedClient = await myClient_1.myClientModel.update(slug, clientData, logoFile);
            const response = {
                success: true,
                data: updatedClient,
                message: 'Client updated successfully'
            };
            res.json(response);
        }
        catch (error) {
            const response = {
                success: false,
                message: error.message
            };
            res.status(500).json(response);
        }
    }
    async delete(req, res) {
        try {
            const { slug } = req.params;
            await myClient_1.myClientModel.delete(slug);
            const response = {
                success: true,
                message: 'Client deleted successfully'
            };
            res.json(response);
        }
        catch (error) {
            const response = {
                success: false,
                message: error.message
            };
            res.status(500).json(response);
        }
    }
}
exports.ClientController = ClientController;
exports.clientController = new ClientController();
//# sourceMappingURL=clientController.js.map