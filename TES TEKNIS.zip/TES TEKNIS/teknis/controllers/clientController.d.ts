import { Request, Response } from 'express';
export declare class ClientController {
    create(req: Request, res: Response): Promise<void>;
    getBySlug(req: Request, res: Response): Promise<void>;
    getAll(req: Request, res: Response): Promise<void>;
    update(req: Request, res: Response): Promise<void>;
    delete(req: Request, res: Response): Promise<void>;
}
export declare const clientController: ClientController;
//# sourceMappingURL=clientController.d.ts.map