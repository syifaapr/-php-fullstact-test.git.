import { Request, Response } from 'express';
import { myClientModel } from '../models/myClient';
import { ClientCreateInput, ClientUpdateInput, ApiResponse } from '../types';

export class ClientController {
  async create(req: Request, res: Response): Promise<void> {
    try {
      const clientData: ClientCreateInput = req.body;
      const logoFile = req.file;

      const newClient = await myClientModel.create(clientData, logoFile);
      
      const response: ApiResponse<typeof newClient> = {
        success: true,
        data: newClient,
        message: 'Client created successfully'
      };

      res.status(201).json(response);
    } catch (error: any) {
      const response: ApiResponse<null> = {
        success: false,
        message: error.message
      };
      res.status(500).json(response);
    }
  }

  async getBySlug(req: Request, res: Response): Promise<void> {
    try {
      const slug = req.params.slug as string;
      const client = await myClientModel.findBySlug(slug);

      if (!client) {
        const response: ApiResponse<null> = {
          success: false,
          message: 'Client not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse<typeof client> = {
        success: true,
        data: client
      };

      res.json(response);
    } catch (error: any) {
      const response: ApiResponse<null> = {
        success: false,
        message: error.message
      };
      res.status(500).json(response);
    }
  }

  async getAll(req: Request, res: Response): Promise<void> {
    try {
      const clients = await myClientModel.findAll();
      
      const response: ApiResponse<typeof clients> = {
        success: true,
        data: clients,
        count: clients.length
      };

      res.json(response);
    } catch (error: any) {
      const response: ApiResponse<null> = {
        success: false,
        message: error.message
      };
      res.status(500).json(response);
    }
  }

  async update(req: Request, res: Response): Promise<void> {
    try {
      const slug = req.params.slug as string;
      const clientData: ClientUpdateInput = req.body;
      const logoFile = req.file;

      const updatedClient = await myClientModel.update(slug, clientData, logoFile);
      
      const response: ApiResponse<typeof updatedClient> = {
        success: true,
        data: updatedClient,
        message: 'Client updated successfully'
      };

      res.json(response);
    } catch (error: any) {
      const response: ApiResponse<null> = {
        success: false,
        message: error.message
      };
      res.status(500).json(response);
    }
  }

  async delete(req: Request, res: Response): Promise<void> {
    try {
      const slug = req.params.slug as string;
      
      await myClientModel.delete(slug);
      
      const response: ApiResponse<null> = {
        success: true,
        message: 'Client deleted successfully'
      };

      res.json(response);
    } catch (error: any) {
      const response: ApiResponse<null> = {
        success: false,
        message: error.message
      };
      res.status(500).json(response);
    }
  }
}

export const clientController = new ClientController();