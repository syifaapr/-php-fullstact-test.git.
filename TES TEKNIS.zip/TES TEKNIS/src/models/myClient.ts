import { pool } from '../config/database';
import { redisClient, connectRedis } from '../config/redis';
import { s3, S3_CONFIG } from '../config/aws';
import { Helpers } from '../utils/helpers';
import { Client, ClientCreateInput, ClientUpdateInput, FileUpload } from '../types';
import { v4 as uuidv4 } from 'uuid';

export class MyClientModel {
  async uploadToS3(file: FileUpload): Promise<string> {
    const fileExtension = file.originalname.split('.').pop();
    const fileName = `client-logos/${uuidv4()}.${fileExtension}`;
    
    const params = {
      Bucket: S3_CONFIG.bucket,
      Key: fileName,
      Body: file.buffer,
      ContentType: file.mimetype,
      ACL: 'public-read' as const,
    };

    const result = await s3.upload(params).promise();
    return result.Location;
  }

  async create(clientData: ClientCreateInput, logoFile?: FileUpload): Promise<Client> {
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');
      const sanitizedData = Helpers.sanitizeClientData(clientData);
      
      if (!Helpers.validateClientPrefix(sanitizedData.client_prefix)) {
        throw new Error('Client prefix must be 1-4 uppercase alphanumeric characters');
      }
      if (logoFile) {
        sanitizedData.client_logo = await this.uploadToS3(logoFile);
      }
      const now = new Date();

      const query = `
        INSERT INTO my_client (
          name, slug, is_project, self_capture, client_prefix, 
          client_logo, address, phone_number, city, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        RETURNING *
      `;

      const values = [
        sanitizedData.name,
        sanitizedData.slug,
        sanitizedData.is_project,
        sanitizedData.self_capture,
        sanitizedData.client_prefix,
        sanitizedData.client_logo,
        sanitizedData.address || null,
        sanitizedData.phone_number || null,
        sanitizedData.city || null,
        now,
        now,
      ];

      const result = await client.query(query, values);
      const newClient = result.rows[0] as Client;

      await connectRedis();
      await redisClient.set(newClient.slug, JSON.stringify(newClient));

      await client.query('COMMIT');
      return newClient;

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async findBySlug(slug: string): Promise<Client | null> {
    await connectRedis();
    const cachedData = await redisClient.get(slug);
    
    if (cachedData) {
      return JSON.parse(cachedData) as Client;
    }
    const query = 'SELECT * FROM my_client WHERE slug = $1 AND deleted_at IS NULL';
    const result = await pool.query(query, [slug]);
    
    if (result.rows.length === 0) {
      return null;
    }

    const clientData = result.rows[0] as Client;
    
    await redisClient.set(slug, JSON.stringify(clientData));
    
    return clientData;
  }

  async findAll(): Promise<Client[]> {
    const query = 'SELECT * FROM my_client WHERE deleted_at IS NULL ORDER BY created_at DESC';
    const result = await pool.query(query);
    return result.rows as Client[];
  }

  async update(slug: string, clientData: ClientUpdateInput, logoFile?: FileUpload): Promise<Client> {
    const dbClient = await pool.connect();
    
    try {
      await dbClient.query('BEGIN');

      if (logoFile) {
        clientData.client_logo = await this.uploadToS3(logoFile);
      }
      clientData.updated_at = new Date();

      const setClauses: string[] = [];
      const values: any[] = [];
      let paramCount = 1;

      Object.keys(clientData).forEach(key => {
        if (key !== 'slug' && clientData[key as keyof ClientUpdateInput] !== undefined) {
          setClauses.push(`${key} = $${paramCount}`);
          values.push(clientData[key as keyof ClientUpdateInput]);
          paramCount++;
        }
      });

      if (setClauses.length === 0) {
        throw new Error('No fields to update');
      }

      values.push(slug);
      const whereClause = `slug = $${paramCount}`;

      const query = `
        UPDATE my_client 
        SET ${setClauses.join(', ')} 
        WHERE ${whereClause} AND deleted_at IS NULL
        RETURNING *
      `;

      const result = await dbClient.query(query, values);
      
      if (result.rows.length === 0) {
        throw new Error('Client not found');
      }

      const updatedClient = result.rows[0] as Client;

      // Update Redis
      await connectRedis();
      await redisClient.del(slug); // Delete old
      await redisClient.set(updatedClient.slug, JSON.stringify(updatedClient)); // Set new

      await dbClient.query('COMMIT');
      return updatedClient;

    } catch (error) {
      await dbClient.query('ROLLBACK');
      throw error;
    } finally {
      dbClient.release();
    }
  }

  async delete(slug: string): Promise<{ message: string }> {
    const dbClient = await pool.connect();
    
    try {
      await dbClient.query('BEGIN');

      const query = `
        UPDATE my_client 
        SET deleted_at = $1 
        WHERE slug = $2 AND deleted_at IS NULL
        RETURNING *
      `;

      const result = await dbClient.query(query, [new Date(), slug]);
      
      if (result.rows.length === 0) {
        throw new Error('Client not found');
      }

      await connectRedis();
      await redisClient.del(slug);

      await dbClient.query('COMMIT');
      return { message: 'Client deleted successfully' };

    } catch (error) {
      await dbClient.query('ROLLBACK');
      throw error;
    } finally {
      dbClient.release();
    }
  }

  async findById(id: number): Promise<Client | null> {
    const query = 'SELECT * FROM my_client WHERE id = $1 AND deleted_at IS NULL';
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return null;
    }

    const clientData = result.rows[0] as Client;
    
    await connectRedis();
    await redisClient.set(clientData.slug, JSON.stringify(clientData));
    
    return clientData;
  }
}

export const myClientModel = new MyClientModel();