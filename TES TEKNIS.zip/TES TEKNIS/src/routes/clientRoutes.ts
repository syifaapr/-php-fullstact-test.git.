import { Router } from 'express';
import { clientController } from '../controllers/clientController';
import { upload, handleUploadError } from '../middleware/upload';

const router = Router();

router.post('/clients', upload.single('client_logo'), clientController.create.bind(clientController));
router.get('/clients', clientController.getAll.bind(clientController));
router.get('/clients/:slug', clientController.getBySlug.bind(clientController));
router.put('/clients/:slug', upload.single('client_logo'), clientController.update.bind(clientController));
router.delete('/clients/:slug', clientController.delete.bind(clientController));

router.use(handleUploadError);

export default router;