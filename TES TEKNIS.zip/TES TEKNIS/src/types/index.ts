//buat interface client
export interface Client {
    id?: number; 
    name: string;
    slug: string;
    is_project: '0' | '1';
    self_capture: string;
    client_prefix: string;
    client_logo: string;
    address?: string;
    phone_number?: string;
    city?: string;
    created_at?: Date;
    updated_at?: Date;
    deleted_at?: Date;
  }
  
  export interface ClientCreateInput {
    name: string;
    slug?: string;
    is_project?: '0' | '1';
    self_capture?: string;
    client_prefix: string;
    client_logo?: string;
    address?: string;
    phone_number?: string;
    city?: string;
    created_at?: Date;
    updated_at?: Date;
  }
  
  export interface ClientUpdateInput {
    name?: string;
    is_project?: '0' | '1';
    self_capture?: string;
    client_prefix?: string;
    client_logo?: string;
    address?: string;
    phone_number?: string;
    city?: string;
    updated_at?: Date;
  }
  
  export interface FileUpload {
    fieldname: string;
    originalname: string;
    encoding: string;
    mimetype: string;
    buffer: Buffer;
    size: number;
  }
  
  export interface ApiResponse<T> {
    success: boolean;
    data?: T;
    message?: string;
    count?: number;
  }