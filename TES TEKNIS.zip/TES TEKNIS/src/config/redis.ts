import { createClient } from 'redis';
import * as dotenv from 'dotenv';

dotenv.config();

if (!process.env.REDIS_URL) {
  throw new Error("miss req");
}

export const redisClient = createClient({
  url: process.env.REDIS_URL!, 
});

redisClient.on('error', (err) => console.error('Redis Client Error', err));
redisClient.on('connect', () => console.log(' Redis connected successfully'));

export const connectRedis = async (): Promise<void> => {
  if (!redisClient.isOpen) {
    await redisClient.connect();
  }
};
