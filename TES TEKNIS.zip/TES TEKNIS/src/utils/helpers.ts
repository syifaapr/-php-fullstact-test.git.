import { ClientCreateInput } from '../types';

export class Helpers {
  static generateSlug(name: string): string {
    return name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9 -]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .substring(0, 100);
  }

  static validateClientPrefix(prefix: string): boolean {
    return /^[A-Z0-9]{1,4}$/.test(prefix);
  }

  static sanitizeClientData(data: ClientCreateInput): ClientCreateInput {
    const sanitized: ClientCreateInput = { ...data };
    
    // Generate slug if not provided
    if (!sanitized.slug) {
      sanitized.slug = this.generateSlug(sanitized.name);
    }

    // Set defaults
    if (!sanitized.is_project) sanitized.is_project = '0';
    if (!sanitized.self_capture) sanitized.self_capture = '1';
    if (!sanitized.client_logo) sanitized.client_logo = 'no-image.jpg';

    return sanitized;
  }
}